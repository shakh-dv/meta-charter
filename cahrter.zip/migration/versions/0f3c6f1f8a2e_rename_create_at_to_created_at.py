"""rename create_at to created_at

Revision ID: 0f3c6f1f8a2e
Revises: 6db522f7944d
Create Date: 2026-03-21 15:10:00.000000

"""
from typing import Sequence, Union

from alembic import op


# revision identifiers, used by Alembic.
revision: str = "0f3c6f1f8a2e"
down_revision: Union[str, Sequence[str], None] = "6db522f7944d"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column("offers", "create_at", new_column_name="created_at")


def downgrade() -> None:
    op.alter_column("offers", "created_at", new_column_name="create_at")
