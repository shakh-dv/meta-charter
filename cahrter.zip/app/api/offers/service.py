from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession

from app.api.offers.repository import OfferRepository
from app.api.offers.schemas import OfferIn, OffersPayloadIn


class OfferService:

    @staticmethod
    def map_offer(offer: OfferIn) -> dict:
        segment = offer.routes[0].segments[0]
        expires_at_utc = datetime.utcnow()
        
        return {
            "provider_id": offer.provider.provider_id,
            "supplier_offer_id": offer.offer_id,
            "origin": segment.departure_city_code,
            "destination": segment.arrival_city_code,
            "departure_date": segment.departure_date,
            "price": offer.price_info.price,
            "currency": offer.price_info.currency,
            "is_active": True,
            "expires_at": expires_at_utc,
            "raw_json": offer.model_dump(),
        }
    

    @staticmethod
    async def save_offers(session: AsyncSession, payload: OffersPayloadIn):
        offers = payload.data.offers

        values = [OfferService.map_offer(o) for o in offers]

        await OfferRepository.batch_upsert(session, values)
        await session.commit()

    @staticmethod
    async def get_offers(session: AsyncSession):
        data = await OfferRepository.get_offers(session)
        return data