from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.offers.schemas import OffersPayloadIn, SaveOffersResponse
from app.api.offers.service import OfferService
from app.db.session import get_session

router = APIRouter(prefix="/offers", tags=["offers"])


@router.post("/import", response_model=SaveOffersResponse)
async def import_offers(payload: OffersPayloadIn, session: AsyncSession = Depends(get_session),) -> SaveOffersResponse:
    await OfferService.save_offers(session, payload)
    return SaveOffersResponse()

@router.get("/export")
async def export_offers(session: AsyncSession = Depends(get_session),):
    data = await OfferService.get_offers(session)
    return data

