

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.offers import Offer


class OfferRepository:

    @staticmethod
    async def batch_upsert(session: AsyncSession, value: list[dict]):
        stmt = insert(Offer).values(value)

        stmt = stmt.on_conflict_do_update(
            index_elements=["provider_id", "supplier_offer_id"],
            set_= {
                "price": stmt.excluded.price,
                "currency": stmt.excluded.currency,
                "expires_at": stmt.excluded.expires_at,
                "is_active": True,
                "raw_json": stmt.excluded.raw_json,
            },
        )

        await session.execute(stmt)

    @staticmethod
    async def get_offers(session: AsyncSession):
        data = select(Offer)

        result = await session.execute(data)
        return result.scalars().all()
        


