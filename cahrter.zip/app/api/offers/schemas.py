from datetime import date

from pydantic import BaseModel


class ProviderIn(BaseModel):
    provider_id: str


class SegmentIn(BaseModel):
    departure_city_code: str
    arrival_city_code: str
    departure_date: date


class RouteIn(BaseModel):
    segments: list[SegmentIn]


class PriceInfoIn(BaseModel):
    price: float
    currency: str


class OfferIn(BaseModel):
    offer_id: str
    provider: ProviderIn
    routes: list[RouteIn]
    price_info: PriceInfoIn


class OffersDataIn(BaseModel):
    offers: list[OfferIn]


class OffersPayloadIn(BaseModel):
    data: OffersDataIn


class SaveOffersResponse(BaseModel):
    status: str = "ok"
