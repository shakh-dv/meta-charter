from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.auth.schemas import LoginIn, RegisterIn, TokenOut
from app.api.auth.service import AuthService
from app.db.session import get_session

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=TokenOut)
async def register(data: RegisterIn, session: AsyncSession = Depends(get_session)) -> TokenOut:
    
    return await AuthService.register(session=session, data=data)


    


@router.post("/login", response_model=TokenOut)
async def login(data: LoginIn, session: AsyncSession = Depends(get_session)) -> TokenOut:
    """Authenticate user and return an access token."""
    return await AuthService.login(session=session, email=data.email, password=data.password)
    ...



