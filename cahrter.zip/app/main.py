import uvicorn
from fastapi import Depends, FastAPI
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.auth.router import router as auth_router
from app.api.offers.router import router as offers_router
from app.db.session import get_session

app = FastAPI()
app.include_router(offers_router)
app.include_router(auth_router)


def run_dev():
    uvicorn.run(
        "app.main:app",
        host="127.0.0.1",
        port=8000,
        reload=True
    )

@app.get("/health/db")
async def db_check(session: AsyncSession = Depends(get_session)):
    result = await session.execute(text("SELECT 1"))
    return {"db": result.scalar()}

