import uuid

from sqlalchemy import JSON, TIMESTAMP, Boolean, Column, Date, Index, Numeric, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from app.db.base import Base


class Offer(Base):
    __tablename__ = 'offers'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    provider_id = Column(String, nullable=False)
    supplier_offer_id = Column(String, nullable=False)

    origin = Column(String, nullable=False)
    destination = Column(String, nullable=False)
    departure_date = Column(Date, nullable=False)

    price = Column(Numeric, nullable=False)
    currency = Column(String)
    
    is_active = Column(Boolean, default=True, nullable=False)
    expires_at = Column(TIMESTAMP, nullable=False)

    raw_json = Column(JSON, nullable=False)

    created_at = Column(TIMESTAMP, server_default=func.now())


    __table_args__ = (
        Index("ux_offer", "provider_id", "supplier_offer_id", unique=True),
        Index("idx_search", "origin", "destination", "departure_date", "price"),
        Index(
            "idx_active_true",
            "origin", "destination", "departure_date", "price",
            postgresql_where=is_active.is_(True)
        ),
    )